
import pygame
from mein_spiel.core.game import Game

def main():
    pygame.init()
    game = Game()
    game.run()
    pygame.quit()
